package Person;
# Class for storing data about a person
#person1.pm
use warnings;
use strict;

1;
